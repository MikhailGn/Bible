ActiveUsers = new Mongo.Collection("activeusers");
Blogposts = new Mongo.Collection("blogposts");

