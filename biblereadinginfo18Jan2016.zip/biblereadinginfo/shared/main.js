Meteor.methods({
	addComment:function(aNewComment){
		if (this.userId){
			aNewComment.createdOn = new Date();
			aNewComment.userId = this.userId;
			return Comments.insert(aNewComment);
		}
		return;
	}
})